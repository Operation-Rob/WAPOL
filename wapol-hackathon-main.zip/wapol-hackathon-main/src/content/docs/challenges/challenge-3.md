---
title: Challenge 3 - Build a virtual assistant for frontline officers
description: Will you accept this challenge?
---

Police Officers must adhere to a set of standards in their conduct, ensuring their actions align with current legislation. When undertaking actions such as arrests, Officers must be confident they are compliant with the law. To ensure precision and adherence to legal standards, Officers require immediate access to legislative information.

## Background

Effective policing requires real-time access to accurate legislative information. This ensures that all actions taken by Officers are in strict accordance with legal guidelines. 

## Objective

Can you develop a way to provide accurate, well-referenced, and justified responses to queries from Police Officers? A chatbot could help Officers make faster and more informed decisions that comply with legal standards.

## Constraints

Any solution to this challenge must be accurate, reliable and accountable. Solutions must also focus on legislation applicable to West Australian Police Officers.

## Potential Solution Approaches

While existing solutions like ChatGPT provide general answers, a tuned model trained specifically on relevant legislation would offer more consistent and accountable responses. Any chatbot will need to be trained on a defined set of legislative documents and scenario-based Q&A pairs to ensure its answers are grounded in the appropriate legal context.

## Data

Briefly outline different types of data required for the challenge. Do not get into the detail here. Just a list of data is sufficient. Also state if the participants need to generate data or can use our data. A link to website will be helpful. The limitations. Include the format of your data table

## Data Dictionary

| No  | Act Name                                             | Sections Description                                                               | Key Points                                                                                                                                                                                                                                           |
| --- | ---------------------------------------------------- | ---------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Criminal Investigation Act 2006                      | Provides detailed legislative guidance on criminal investigations.                 | - Powers for stopping, searching, and arresting individuals.<br> - Procedures for handling suspects and evidence.<br> - Guidelines for use of force and obtaining warrants.                                                                          |
| 2   | Criminal Investigation (Identifying People) Act 2002 | Details the procedures for obtaining personal details and identifying particulars. | - Procedures for obtaining DNA samples, photographs, and other identifying features.<br> - Guidelines for handling volunteers and suspects.<br> - Specific rules for dealing with minors and incapacitated persons.                                  |
| 3   | Criminal Code Act Compilation Act 1913               | Comprehensive code covering various offences and criminal procedures.              | - Definitions and penalties for various crimes.<br> - Legal justifications and defenses.<br> - Procedures for arrest, search, and seizure.                                                                                                           |
| 4   | Criminal Procedure Act 2004                          | Covers the procedural aspects of criminal law.                                     | - Processes for charging and trying offences.<br> - Rights of the accused and procedural safeguards.<br> - Rules for evidence presentation and witness handling.                                                                                     |
| 5   | Misuse of Drugs Act 1981                             | Focuses on the regulation and control of drug use and trafficking.                 | - Offences related to possession, trafficking, and manufacture of drugs.<br> - Powers of police officers in drug-related investigations.<br> - Procedures for issuing Cannabis Intervention Requirements (CIRs) and dealing with juvenile offenders. |

## Example Entry From Q&A Pairs

Scenario: An Officer is patrolling a neighbourhood at night and notices a
person peering into car windows with a flashlight.

- Options:
  1. Immediately arrest the person for attempted theft.
  2. Observe from a distance to gather more evidence.
  3. Question the person about their intentions.
  4. Ignore the person and continue the patrol.
- Correct Answer: 3) Question the person about their intentions.
- Reference: Section 445 - “Damaging property: Any person who damages property is committing an offence.”
- Explanation: Questioning the individual helps determine if an offence is occurring without prematurely escalating the situation

## Data Sources

- Criminal Investigation Act 2006: Provides the framework for criminal investigations, including the powers and responsibilities of police Officers.
- Criminal Investigation (Identifying People) Act 2002: Details the procedures for obtaining and using personal details and identifying particulars in forensic investigations.
- Criminal Code Act Compilation Act 1913: A comprehensive legal code defining various criminal offences and procedures.
- Criminal Procedure Act 2004: Outlines the procedural aspects of criminal law, including trial processes and the rights of the accused.
- Misuse of Drugs Act 1981: Focuses on the regulation of drugs, detailing offences and the powers of police in drug-related cases.
- Q&A Pairs: Provides scenario-based questions and answers to guide Officers in making legally compliant decisions.

## Downloads

- [Project Outline](/Challenge3-VirtualAssistant-ProjectOutline.pdf)
- [Challenge 3 Data](https://sawapolhackathon.blob.core.windows.net/data/Challenge3-Data-VirtualChatbotAssistant.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)