---
title: Challenge 1 - Optimise our emergency response
description: Will you accept this challenge?
---

The challenge is about optimising the allocation of resources and time in response to incidents.

## Background

Numerous incidents are reported to the WA Police every day. Each incident requires a timely and efficient response. Incidents have a priority level and the types of resources and capabilities needed. Police stations have different resources, and at any given time, some resources may be unavailable due to maintenance or deployment elsewhere. Ideally, the nearest station should respond, but this isn’t always possible due to resource availability and location. Currently these resource allocations are done manually.

## Objective

Your objective is to develop new approaches to maximising the number of incidents responded to by the WA Police, while minimising the response time. You will need to consider the types of resources required by an incident as well as the information about the status and location of resources.
The challenge aims to optimise resource allocation and emergency route planning to:

- Maximise the number of incidents responded to.
- Minimise response time.
- Optimise resource usage.
- •	Maximise information gathered from incidents. How will you track resource locations and allocate resources based on incident priority and resource requirements?

## Constraints

- Limited Resources: Different types and numbers of resources are available at a certain time at a certain location.
- Resource Locations and Availability: Resources may be engaged elsewhere or under maintenance.
- Incident Type and Priority: Priorities influence the time required for response and number of resource allocation.
- Existing Incidents: Ensuring resources are not depleted by ongoing incidents and can respond to new incidents timely.
- Limited number of resources available at any time.

## Potential Solution

1. Algorithmic Optimisation: Develop algorithms to prioritise and allocate resources based on incident priority, resource availability, and response time optimisation.
2. Use techniques such as Linear Programming, Mixed-Integer Programming or Heuristic Algorithms to dynamically allocate resources to incidents.

## Data

- Number and type of capabilities available: Details of capabilities by type and availability.
- Dynamic locations of capabilities: Current status of capabilities (e.g., on job, under maintenance).
- Incident List with Location and Priority: Details of incidents, including location and priority.
- Road Map: Geographical data for route planning.

## Data Dictionary

| No  | Column Name       | Data Type | Description                                                                                                                                                  |
| --- | ----------------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1   | OBJECTID          | Integer   | Unique identifier for each record.                                                                                                                           |
| 2   | ROAD_NO           | String    | Road number associated with the location of the incident.                                                                                                    |
| 3   | ROAD_NAME         | String    | Official name of the road where the incident occurred.                                                                                                       |
| 4   | COMMON_ROAD_NAME  | String    | Commonly known name of the road where the incident occurred.                                                                                                 |
| 5   | CWAY              | String    | Carriageway designation, indicating the specific part of the road used by vehicles.                                                                          |
| 6   | SLK               | Float     | Straight Line Kilometre, indicating the distance from a defined starting point in kilometres.                                                                |
| 7   | INTERSECTION_NO   | Integer   | Unique identifier for the intersection related to the incident.                                                                                              |
| 8   | INTERSECTION_DESC | String    | Description of the intersection where the incident occurred.                                                                                                 |
| 9   | LONGITUDE         | Float     | Longitude coordinate of the incident location.                                                                                                               |
| 10  | LATITUDE          | Float     | Latitude coordinate of the incident location.                                                                                                                |
| 11  | CRASH_TIME        | Time      | Time indicating when the incident occurred.                                                                                                                  |
| 12  | INCIDENT TYPE     | String    | Category of the incident based on severity or type.                                                                                                          |
| 13  | PRIORITY          | String    | Priority level of the incident, indicating urgency for response. Each Priority has different response time and different number of capabilities requirement. |
| 14  | CAPABILITY 1      | String    | Resource required for each incident.                                                                                                                         |

Participants should generate synthetic data if more data is needed for testing the algorithms.

## Downloads

- [Project Outline](/Challenge1-ResourceOptimisation-ProjectOutline.pdf)
- [Challenge 1 Data](https://sawapolhackathon.blob.core.windows.net/data/Challenge1-Data-OptimiseEmergencyReponse.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)