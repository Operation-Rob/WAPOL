---
title: Challenge 5 - Ensure that critical information is understood during a 000 call
description: Will you accept this challenge?
---

Design an application that can support operators handling 000 calls by assisting them to determine different types of emergency and ensure that all information needed is collected.

## Background

When incidents are reported to 000 operators, they often encounter challenges in collecting critical information. The high-stress nature of 000 calls can hinder operators from obtaining and accurately recording all necessary information from callers. Furthermore, requested information may occasionally be missed or insufficiently provided, with such errors frequently being identified only after the call has concluded.

## Objective

Can you help us support 000 operators to determine the type of emergency and ensure that all necessary information is obtained? Your solution need sto consider the rapid, real-time nature of emergency calls.

## Constraints

There may be technical challenges in addressing poor audio quality, dealing with callers in high stress or emotional states who lack coherency, and assisting callers who do not speak English as their first language. Additionally, it can be difficult to determine what constitutes sufficient information to consider a required caller question as answered.

## Potential Solution

One potential solution is to utilize machine learning and deep learning techniques to identify the type of emergency at the early stages of a call. A chatbot could assist operators by guiding them to ask the appropriate questions and ensuring that all necessary information is obtained.

## Data

700 independent 911 recordings with metadata provided including description. A trimmed version of only the first 6 seconds is also available.

## Data Dictionary

Provided separately.

## Downloads

- [Project Outline](/Challenge5-OperatorSpeakerTranscription-ProjectOutline.pdf)
- [Challenge 5 Data - first 6 seconds](https://sawapolhackathon.blob.core.windows.net/data/Challenge5a-First-6-seconds.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 1-100 and metadata](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_001-100.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 101-200](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_101-200.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 201-300](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_201-300.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 301-400](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_301-400.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 401-499](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_401-499.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 501-600](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_501-600.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)

- [Challenge 5 Data - calls 701-743](https://sawapolhackathon.blob.core.windows.net/data/Challenge5-call_701-743.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)