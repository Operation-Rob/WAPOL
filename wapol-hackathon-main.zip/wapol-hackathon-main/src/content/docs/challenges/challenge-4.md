---
title: Challenge 4 - Extract key information about police investigations from operational resources
description: Will you accept this challenge?
---

## Background

Information and evidence from investigations is often collaboratively shared and discussed in text conversations on a communication platform. This information is difficult to access, analyse and it is time consuming to extract key information for reporting and to pass on to related investigations. Can you help improve how we search across multiple chats to find key entities and events of interest, and potential links between chats?

There are number of scenarios where you might like to focus your solution:
1.	Improving how intelligence analysts search through many chats to find the critical information (entities, relationships, times).
2.	Identifying potential links between investigations.
3.	Improving the speed with which ongoing investigations can identify key entities or relationships of interest.


## Objective

Can you extract meaningful data from the chat logs and present this in an intuitive and easy to consume format?

Meaningful data points could include:
1.	The timeline of events in the correct order.
2.	Named Entities (ie. people, places, vehicles and objects).
3.	Relationships (ie. person to person, person to object/vehicle, object/vehicle to object/vehicle, person to incident, incident to incident, person to location, object/vehicle to location).
4.	A summary of the conversation.

These data points need to be presented back to investigators in an intuitive, and easy to consume manner.


## Constraints

Contestants will be provided with a mix of text and image data and will be required to perform analysis to extract insights, being imaginative and creative with how to detect entities and draw relationships between them.

## Potential Solution Approaches

Potential solutions could consider:

- Natural Language Programming techniques, including Named Entity Recognition and Relationship Extraction.
- The use of Large Language Models for processing and summarising chat logs.

A potential user interface could incorporate some of the following elements:

-	It could display the chats and messages in an easy-to-read manner.
-	Users would have the option to search for messages by chat name, date range, entities, relationships and text descriptions.
-	Entity-relationship mapping should be presented in an easy-to-view format.
-	Entities and relationships could be clustered together by degrees of similarity both within chats and across multiple chats.
-	There could be an option to flag messages for later review.
-	There could be an ability to extract excerpts of conversations into other file types for further analysis.
-	Results and insights could be ranked based on a similarity score for matches to entities and relationships.
-	Officers often prefer searching for relationships using plain English search phrases.
-	Being able to use text to search for similarities and patterns in associated images would be very useful.


## Data

A mock dataset of chats has been provided containing conversations similar to those in operational chats, along with corresponding images and attachments.

A summary of some common police terminology within the chats and their descriptions are provided below:


| Terminology        | Description                                                                                                         |
|--------------------|---------------------------------------------------------------------------------------------------------------------|
| CCTV               | Refers to cameras which record images/videos of people in certain public places including town centres, roads, airports, and on public transport. CCTV images/video can be used as evidence in court. |
| ANPR               | Automatic Number Plate Recognition technology reads licence plates on vehicles.                                     |
| Incident Report    | Report created by police officers for an incident (offence/crime).                                                  |
| Body Worn Camera   | Cameras attached to the uniform of police officers, can be used to replay critical footage of an incident.          |
| Telco Pings        | Signals sent by your mobile phone to cell towers, allowing telecommunications companies to determine your location.  |
| Forensic Report    | A report containing information on key evidence obtained in an investigation.                                       |
| Suspect            | Person of interest thought to be guilty of a crime.                                                                |

Each chat is provided as a .csv file in a zip folder. All attachments to the chat are provided in the same zip folder and have the naming convention “Attachment_Name-DD-MM-YYYY-HH-NN.xyz”, with the breakdown as below:

| Attachment_Name        | The name given to an attachment            |
|------------------------|---------------------------------------------|
| DD-MM-YYYY-HH-NN       | Datetime of the message in the chat         |
| xyz                    | File extension placeholder                  |

These filenames are appended to the end of a message in a chat in the format: 
“<attached: Attachment_Name-DD-MM-YYYY-HH-NN.xyz>“
Example message with attachment:

| [Date, Time]           | Officer Name        | Message                                                                                          |
|----------------------|---------------------|--------------------------------------------------------------------------------------------------|
| [01/01/2024, 14:58]  | Officer Reynolds:   | We identified a stolen white falcon from the crime scene, here’s a photo: attached:White_Falcon-2024-01-01-14-58.jpg |

## Data Dictionary 

| No  | Column Name     | Data Type | Description                                                                                 |
|-----|-----------------|-----------|---------------------------------------------------------------------------------------------|
| 1   | [Date, Time]    | Datetime  | [DD/MM/YYYY, HH:NN]  Date and 24-hour time when the message was sent, separated by a comma  |
| 2   | Officer Name    | String    | Name of the person who sent the message                                                     |
| 3   | Message         | String    | Free text message, can include attached filenames                                           |

## Downloads

- [Project Outline](/Challenge4-ExtractDataFromOperationalResources-ProjectOutline.pdf)
- [Challenge 4 Data](https://sawapolhackathon.blob.core.windows.net/data/Challenge4-DATA-Extract%20Key%20Information.zip?sp=r&st=2024-06-20T10:48:06Z&se=2024-06-23T15:00:00Z&spr=https&sv=2022-11-02&sr=c&sig=IifG%2BMvt8fJfH7PJa8dwCl2NoF6XZjBK5OYKCe2lQBY%3D)