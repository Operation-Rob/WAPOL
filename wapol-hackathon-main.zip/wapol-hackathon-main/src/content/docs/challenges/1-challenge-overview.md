---
title: Challenges Overview
description: All the challenges in one place
---

The West Australian Police Force has identified five Challenges they would like WAPOL x WADSIH Participants to develop solutions for. Each of the Challenges are paired with supporting data and dedicated mentors.

These Challenges are important and complex. The details on each Challenge and the data you can use to inform your solutions can be found by following the links below:


## The Challenges are:

### <a href="/challenges/challenge-1">Challenge 1 - Optimise our emergency response</a>

The challenge is about optimising the allocation of resources and time in response to incidents.

### <a href="/challenges/challenge-2">Challenge 2 - Predicting Vehicle Location Using ANPR Camera Reads</a>

When a vehicle is reported as stolen, Police will instruct Automatic Number Plate Recognition (ANPR) cameras across Western Australia to send an alert if they see the stolen car’s license plate. When this alert is received, officers are tasked with organising an intercept of the identified vehicle by attempting to manually predict the vehicle’s location.

### <a href="/challenges/challenge-3">Challenge 3 - Build a virtual assistant for frontline officers</a>

Police Officers must adhere to a set of standards in their conduct, ensuring their actions align with current legislation. When undertaking actions such as arrests, Officers must be confident they are compliant with the law. To ensure precision and adherence to legal standards, Officers require immediate access to legislative information.

### <a href="/challenges/challenge-4">Challenge 4 - Extract key information about police investigations from operational resources</a>

Information and evidence from investigations is often collaboratively shared and discussed in text conversations on a communication platform. This information is difficult to access, analyse and it is time consuming to extract key information for reporting and to pass on to related investigations. Can you help improve how we search across multiple chats to find key entities and events of interest, and potential links between chats?

### <a href="/challenges/challenge-5">Challenge 5 - Ensure that critical information is understood during a 000 call</a>

Design an application that can support operators handling 000 calls by assisting them to determine different types of emergency and ensure that all information needed is collected.