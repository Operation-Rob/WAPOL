---
title: Accessing the Data
description: How to access the data for completing the challenges
---

## Downloading source data

Each page for the challenges will have a link to each file of source data for that challenge. Some files are relevant to more than one challenge. This will be a link to a file or zip file containing the data.

Please download the data provided for the challenges you are interested in.
