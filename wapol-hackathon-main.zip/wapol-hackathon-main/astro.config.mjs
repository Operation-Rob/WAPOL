import { defineConfig } from "astro/config";
import starlight from "@astrojs/starlight";

// https://astro.build/config
export default defineConfig({
  site: "https://wapol-hackathon.github.io/info",
  integrations: [
    starlight({
      title: "WAPOL Hackathon",
      logo: {
        src: "./src/assets/wa_data_science_logo.jpg",
        alt: "WA Data Science Innovation Hub",
      },
      social: {
        github:
          "https://github.com/wa-data-science-innovation-hub/wapol-hackathon",
      },
      locales: {
        root: {
          label: "English",
          lang: "en",
        },
      },
      sidebar: [
        {
          label: "About",
          items: [
            // Each item here is one entry in the navigation menu.
            { label: "Accessing the Data", link: "/about/access-data/" },
          ],
        },
        {
          label: "Challenges",
          autogenerate: { directory: "challenges" },
        },
      ],
    }),
  ],
});
